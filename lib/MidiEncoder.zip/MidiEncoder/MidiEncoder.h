/*
  Released into the public domain.
*/
#ifndef MidiEncoder_h
#define MidiEncoder_h

#include <boards.h>
#include "Arduino.h"

class MidiEncoder
{
  public:
    MidiEncoder(int pinA, int pinB);
	int read();

  private:
    int _pinA;
	int _pinB;
	int _old_AB;
};

#endif