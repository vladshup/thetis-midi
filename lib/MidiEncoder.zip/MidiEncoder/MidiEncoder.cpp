#include <boards.h>
#include "Arduino.h"
#include "MidiEncoder.h"

MidiEncoder::MidiEncoder(int pinA, int pinB)
{
  pinMode(pinA, INPUT_PULLUP);
  _pinA = pinA;
  pinMode(pinB, INPUT_PULLUP);
  _pinB = pinB;
  _old_AB =0;
}

int MidiEncoder::read() 
{
 int8_t _enc_states[] = {0,127,1,0,1,0,0,127,127,0,0,1,0,1,127,0}; 
 _old_AB <<= 2;                   //remember previous state
 _old_AB |= ((digitalRead (_pinB) << 1) | digitalRead (_pinA));
 return ( _enc_states[( _old_AB & 0x0f )]);  	
}
