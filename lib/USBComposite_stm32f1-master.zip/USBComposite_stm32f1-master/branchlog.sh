svn log https://github.com/arpruss/USBComposite_stm32f1/branches/abstracted
