/*
  Released into the public domain.
*/
#ifndef MidiPot_h
#define MidiPot_h

#include <boards.h>
#include "Arduino.h"

class MidiPot
{
  public:
    MidiPot(int pinA);
	bool read();
	int  value;

  private:
    int _pinA;
	unsigned int _old_value;
	unsigned int _new_value;
	unsigned int _threshold;
};

#endif