#include <boards.h>
#include "Arduino.h"
#include "MidiPot.h"

MidiPot::MidiPot(int pinA)
	{
		pinMode(pinA, INPUT);
		_pinA = pinA;
		_threshold = 1;
	}


bool MidiPot::read() 
{	
  _new_value = analogRead(_pinA) / 32;// convert 0-4095 to a value between 0-127
  // If difference between new_value and old_value is grater than threshold
  if ((_new_value > _old_value && _new_value - _old_value > _threshold) ||
	  (_new_value < _old_value && _old_value - _new_value > _threshold)) {
	this->value = _old_value = _new_value;		  
	return true;	
	} else {
	this->value = _old_value;		
	return false;	
	}
	
}

